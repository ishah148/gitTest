import React from 'react';

const ErrorMessage = () => {
  return (
    <div>
      <h1>Something was wrong</h1>
    </div>
  );
};

export default ErrorMessage;
